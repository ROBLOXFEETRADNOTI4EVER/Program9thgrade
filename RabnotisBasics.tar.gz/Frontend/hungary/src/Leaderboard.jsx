import React, { useEffect, useState } from 'react';

export default function Leaderboard() {
  const [players, setPlayers] = useState([]);

  useEffect(() => {
    const fetchapi = async () => {
      try {
        const result = await fetch('http://187.33.144.222:2850/game/');
        const data = await result.json();
        const processedData = data.map(player => {
          const [hours, minutes, seconds] = player.playtime.split(':').map(Number);
          const totalSeconds = hours * 3600 + minutes * 60 + seconds;
          return { ...player, playtime: totalSeconds };
        });
        setPlayers(processedData);
      } catch (error) {
        console.error("Failed to fetch players:", error);
      }
    };

    fetchapi();
    const interval = setInterval(fetchapi, 60000); 
    return () => clearInterval(interval);
  }, []);

  const formatTime = (totalSeconds) => {
    const hours = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
    const minutes = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
    const seconds = Math.floor(totalSeconds % 60).toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
  };

  const calculateEfficiency = (player) => {
    return player.playtime > 0 ? (player.tasks_Solved / player.playtime).toFixed(4) : 0;
  };

  const mostTasks = [...players].sort((a, b) => b.tasks_Solved - a.tasks_Solved);
  const fastestTimes = [...players].sort((a, b) => a.playtime - b.playtime);
  const topEfficiency = [...players].sort((a, b) => 
    calculateEfficiency(b) - calculateEfficiency(a)
  );

  const leaderboardCard = (title, data, metric, highlight) => (
    <div className="card shadow-lg h-100 border-0" style={{ 
      minHeight: '400px',
      background: 'linear-gradient(145deg, #f8f9fa 0%, #e9ecef 100%)',
      borderRadius: '15px',
      overflow: 'hidden'
    }}>
      <div className="card-header p-3" style={{
        background: '#2b2b2b',
        borderBottom: '3px solid #1a1a1a'
      }}>
        <h3 className="mb-1 text-uppercase font-weight-bold" style={{ 
          color: '#fff',
          fontSize: '1.4rem',
          letterSpacing: '1px'
        }}>
          {title}
        </h3>
        <h4 className="mb-0" style={{ color: highlight }}>
          {data[0] ? metric === 'playtime' ? formatTime(data[0][metric]) : 
            metric === 'efficiency' ? calculateEfficiency(data[0]) :
            data[0][metric] : 'N/A'}
        </h4>
      </div>
      <ul className="list-group list-group-flush scrollable-list" style={{ maxHeight: '340px' }}>
        {data.slice(0, 5).map((player, index) => (
          <li key={player._id} className="list-group-item d-flex justify-content-between align-items-center py-2"
              style={{
                background: index % 2 === 0 ? '#f8f9fa' : '#e9ecef',
                borderColor: '#dee2e6',
                transition: 'all 0.2s ease'
              }}>
            <div className="d-flex flex-column">
              <span className="font-weight-bold" style={{ color: '#1a1a1a', fontSize: '1.1rem' }}>
                {player.username}
              </span>
              <span style={{ color: '#6c757d', fontSize: '0.9rem' }}>
                {player.tasks_Solved} tasks · {formatTime(player.playtime)}
              </span>
            </div>
            <span className="badge rounded-pill" style={{ 
              background: '#2b2b2b',
              color: '#fff',
              fontSize: '1rem',
              minWidth: '40px',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}>
              {metric === 'efficiency' ? calculateEfficiency(player) : player[metric]}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );

  return (
    <div className="container mt-4" style={{ maxWidth: '1400px' }}>
      <h1 className="text-center mb-5 display-4 font-weight-bold" style={{ 
        color: '#1a1a1a',
        textShadow: '2px 2px 4px rgba(0,0,0,0.1)',
        letterSpacing: '2px'
      }}>
        LEADERBOARDS
      </h1>
      <div className="row g-4">
        <div className="col-lg-4">
          {leaderboardCard("Most Tasks Completed", mostTasks, "tasks_Solved", '#4a90e2')}
        </div>
        <div className="col-lg-4">
          {leaderboardCard("Speed Champions", fastestTimes, "playtime", '#34d399')}
        </div>
        <div className="col-lg-4">
          {leaderboardCard("Efficiency Masters", topEfficiency, "efficiency", '#fbbf24')}
        </div>
      </div>
    </div>
  );
}