import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-dark text-light text-center mt-5 mb-0 py-5">
      <div className="container">
        <p className="mb-2">
          Rabnotis Leaderboard for the Game © {new Date().getFullYear()}
        </p>
        <small>
          Developed by <strong>Balázs Szabó</strong> (Frontend & Backend) and <strong>Rajnai Kristóf</strong> (Game Development +  Design)
        </small>
      </div>
    </footer>
  );
}
