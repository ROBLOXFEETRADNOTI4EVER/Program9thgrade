import React, { useState, useEffect, useCallback } from "react";

export default function Header() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [grade, setGrade] = useState("");
  const [classSection, setClassSection] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  // Validate token and check if it's expired
  const isTokenValid = useCallback((token) => {
    if (!token) return false;
    
    try {
      // Decode JWT payload
      const payload = JSON.parse(atob(token.split('.')[1]));
      const expDate = new Date(payload.exp * 1000);
      return expDate > new Date();
    } catch (e) {
      console.error("Invalid token format", e);
      return false;
    }
  }, []);

  // Logout handler - extracted as a separate function to avoid useEffect dependency issues
  const handleLogout = useCallback(() => {
    localStorage.removeItem("jwt");
    localStorage.removeItem("user");
    
    setIsLoggedIn(false);
    setShowLogin(false);
    setUsername("");
    setPassword("");
    setGrade("");
    setClassSection("");
  }, []);

  // Check token validity on component mount and at intervals
  useEffect(() => {
    const checkTokenValidity = () => {
      const token = localStorage.getItem("jwt");
      
      if (token && isTokenValid(token)) {
        const userData = localStorage.getItem("user");
        if (userData) {
          setIsLoggedIn(true);
          const parsedUserData = JSON.parse(userData);
          setUsername(parsedUserData.Username || "");
        }
      } else if (isLoggedIn) {
        // Only trigger logout if currently logged in
        handleLogout();
      }
    };

    // Check on mount
    checkTokenValidity();
    
    // Set up periodic token validation check
    const tokenCheckInterval = setInterval(checkTokenValidity, 30000); // Every 30 seconds
    
    return () => clearInterval(tokenCheckInterval);
  }, [isLoggedIn, isTokenValid, handleLogout]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    
    try {
      if (isLogin) {
        // Login logic
        const response = await fetch("http://187.33.144.222:2850/game/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            Username: username,
            Password: password
          }),
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.error || data.erorr || "Login failed");
        }
        
        // The backend uses capital JWT for login response
        const token = data.JWT;
        if (!token) {
          throw new Error("No token received from server");
        }
        
        // Store JWT and user data
        localStorage.setItem("jwt", token);
        localStorage.setItem("user", JSON.stringify({
          Username: username
        }));
        
        setIsLoggedIn(true);
        setShowLogin(false);
      } else {
        // Registration logic
        const response = await fetch("http://187.33.144.222:2850/game/register", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            Username: username,
            Password: password,
            Year: parseInt(grade),
            Class: classSection
          }),
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.error || "Registration failed");
        }
        
        // The backend uses lowercase jwt for register response
        const token = data.jwt;
        if (!token) {
          throw new Error("No token received from server");
        }
        
        // Store JWT and user data
        localStorage.setItem("jwt", token);
        localStorage.setItem("user", JSON.stringify({
          Username: username,
          Year: parseInt(grade),
          Class: classSection,
          _id: data.Usershcema?._id
        }));
        
        setIsLoggedIn(true);
        setShowLogin(false);
      }
    } catch (error) {
      console.error("Auth error:", error);
      setError(error.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  const switchToRegister = () => {
    setIsLogin(false);
    setError("");
    setPassword("");
  };

  const switchToLogin = () => {
    setIsLogin(true);
    setError("");
    setPassword("");
    setGrade("");
    setClassSection("");
  };

  return (
    <>
      <hr style={{ 
        border: 0, 
        height: '1px', 
        backgroundImage: 'linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0))'
      }} />
  
      <div className="container">
        {/* Header Button */}
        <div className="d-flex justify-content-end my-2 px-2">
          <button
            className="btn btn-dark rounded-pill"
            onClick={() => isLoggedIn ? handleLogout() : setShowLogin(!showLogin)}
            aria-label={isLoggedIn ? "Logout" : "Login or Register"}
          >
            {!isLoggedIn ? "Login/Register" : "Logout"}
          </button>
        </div>

        {/* Login/Register Form */}
        {showLogin && (
          <div className="card p-3 shadow-sm">
            <h5 className="text-center">{isLogin ? "Login" : "Register"}</h5>
            <div className="mb-3">
              <button 
                type="button"
                className={`btn btn-sm ${isLogin ? 'btn-primary' : 'btn-outline-primary'} me-2`}
                onClick={switchToLogin}
              >
                Login
              </button>
              <button 
                type="button"
                className={`btn btn-sm ${!isLogin ? 'btn-primary' : 'btn-outline-primary'}`}
                onClick={switchToRegister}
              >
                Register
              </button>
            </div>
            
            {error && (
              <div className="alert alert-danger" role="alert">
                {error}
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <input
                  type="text"
                  className="form-control"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Username"
                  required
                  aria-label="Username"
                />
              </div>
              <div className="mb-3">
                <input
                  type="password"
                  className="form-control"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  required
                  aria-label="Password"
                />
              </div>

              {/* Only show grade and class selection for registration */}
              {!isLogin && (
                <>
                  {/* Grade Selection */}
                  <div className="mb-3">
                    <h6>Select Your Grade:</h6>
                    <div className="d-flex flex-wrap">
                      {[9, 10, 11, 12, 13].map((g) => (
                        <div key={g} className="form-check me-3 mb-2">
                          <input
                            id={`grade-${g}`}
                            type="radio"
                            name="grade"
                            value={g}
                            checked={grade === g.toString()}
                            onChange={(e) => setGrade(e.target.value)}
                            className="form-check-input"
                            required={!isLogin}
                          />
                          <label className="form-check-label" htmlFor={`grade-${g}`}>
                            {g}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Class Selection */}
                  <div className="mb-3">
                    <h6>Select Your Class:</h6>
                    <div className="d-flex flex-wrap">
                      {["A", "B", "C", "D"].map((c) => (
                        <div key={c} className="form-check me-3 mb-2">
                          <input
                            id={`class-${c}`}
                            type="radio"
                            name="classSection"
                            value={c}
                            checked={classSection === c}
                            onChange={(e) => setClassSection(e.target.value)}
                            className="form-check-input"
                            required={!isLogin}
                          />
                          <label className="form-check-label" htmlFor={`class-${c}`}>
                            {c}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {/* Submit Button */}
              <button 
                type="submit" 
                className="btn btn-dark w-100"
                disabled={loading}
              >
                {loading ? (
                  <span>
                    <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    <span className="ms-2">Processing...</span>
                  </span>
                ) : (
                  isLogin ? "Login" : "Register"
                )}
              </button>
            </form>
          </div>
        )}
      </div>
    </>
  );
}
