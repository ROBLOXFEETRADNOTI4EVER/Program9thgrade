const express = require('express');

// schemas 
// -----------------------------------------------------------
const PlayerSchema = require('../Models/Player');
const UserSchema = require('../Models/radnotiStudent')

// -----------------------------------------------------------
//

const Session = require('../Models/Session')
const mongoose = require('mongoose')
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken')


const creatToken = (_id) =>{
    return  jwt.sign({_id},process.env.JWTCODE,{expiresIn: '1h'})
  }
const saltRounds = 10;
// get all players
const getallplayers = async(req,res) =>{
    const players = await PlayerSchema.find({}).sort({createdAt: -1 })
    res.status(200).json(players)
}



// get a single player
const getplayer = async(req,res) =>{
    try {
        
    
    const {id} = req.params
    if(!mongoose.Types.ObjectId.isValid(id)) res.status(404).json({error:"Couldn't find that player"})
    const player = await PlayerSchema.findById(id)

    if(!player) {
        return res.status(404).json({error:"Couldn't find that player"})
    }

    res.status(200).json(player)
 } catch (error) {
        
    }
}

// creat a new datasheet
const creatnewdatasheet = async(req,res) =>{
    try {
        
        console.log(req.body)
        const {username,playtime, tasks_Solved} = req.body;
            const playerSchema = await PlayerSchema.create({
                username, playtime, tasks_Solved
    })
            res.status(200).json(playerSchema)
        } catch (error) {
            console.error(error)
            res.status(400).json({error: error})
        }
         
}

// delete  a players data
const deletepPlayerData = async(req,res) =>{
    try {
        const {key} = req.body
        
        if(key !== process.env.APIKEY || !key){
            return res.status(400).json({error:"You can't use my site brother withouht my api key"})
        }

        const {id} = req.params
        if(!mongoose.Types.ObjectId.isValid(id)) res.status(404).json({error:"Couldn't find that player"})
            const player = await PlayerSchema.findByIdAndDelete(id)
        res.status(200).json(player)
        
    } catch (error) {
        console.log(error)
        res.status(404).json({error:"THere was an error"})
    }
}


// delete a specific players information

const deletePlayers = async(req,res) =>{
    try {
        const {key} = await req.body
        
        if(key !== process.env.APIKEY || !key){
            return res.status(400).json({error:"You can't use my site brother withouht my api key"})
        }
        const players = await PlayerSchema.deleteMany()
        if(players === null) res.status(404).json({error: "not found the player"})
        console.log(players);
        res.status(200).json(players)
    } catch (error) {
        console.error(error)
        res.status(500).json({error: "there was a server error"})
    }
}


// update a players data

const updateplayer = async(req,res) =>{
    try {
        
        const {key} = await req.body
        
        if(key !== process.env.APIKEY || !key){
            return res.status(400).json({error:"You can't use my site brother withouht my api key"})
        }
    
        const { id } = req.params

        if(!mongoose.Types.ObjectId.isValid(id)) res.status(404).json({error:"Couldn't find that player"})

        const player = await PlayerSchema.findByIdAndUpdate({_id: id}, {
          
            ...req.body
        })

    if(!player){
        res.status(400).json({error:"no play data  found"})
    }

    res.status(200).json(player)
 } catch (error) {
        console.error(error)
        res.status(500).json(error)
    }
}


const debugregisterPlayer = async(req,res) =>{
    try {
        const {key} = await req.body
        
        if(key !== process.env.APIKEY || !key){
            return res.status(400).json({error:"You can't use my site brother withouht my api key"})
        }

        let value = false 
        let hashedpass = "$2b$10$LOofpMvzFX4khDZxqxmkfes4g.TY0aVxmMG.Wz77FOTImwUYFaDpi" // Example hashed password 
    const {password,username,checka,checkb} = await req.body

  const hasshed = await   bcrypt.hash(password, saltRounds,)

 const match = await bcrypt.compare(password, hashedpass);

 if(match) {value = true

 }
 else{
    value = false
 }
        
//   const checkinga =  bcrypt.compare(checka,checkb,)

    res.json({username:username,password:password, HashedPassword: hasshed,ISpasswordAdmin: value}) 

}  catch (error) {
        
    }
}

const registerPlayer = async(req,res) =>{
    try {
        let value = false 
        let hashedpass = "$2b$10$LOofpMvzFX4khDZxqxmkfes4g.TY0aVxmMG.Wz77FOTImwUYFaDpi" // Example hashed password 
    let {Password,Username,Class,Year} = await req.body

    if (!Password || !Username || !Class || !Year) {
        return res.status(400).json({ error: "You forgot to fill some fields in" });
    }
    
    if (!["A", "B", "C", "D", "Else"].includes(Class)) {
        return res.status(400).json({ error: "Invalid class selection" });
    }
    
    if (![9, 10, 11, 12, 13, "Else"].includes(Year)) {
        return res.status(400).json({ error: "Invalid year selection" });
    }
    
    if (!/^[a-zA-Z0-9_]+$/.test(Username) || /^(admin|root|moderator|system)$/i.test(Username)) {
        return res.status(400).json({ error: "Invalid username" });
    }
    if (!/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&_])[A-Za-z\d@$!%*?&_]{8,20}$/.test(Password)) {
        return res.status(400).json({ error: "Invalid password: Must be 8-20 characters long, include at least one uppercase letter, one lowercase letter, one number, and one special character." });
    }
    
    const Userr = UserSchema
    

    let hasshed = await   bcrypt.hash(Password, saltRounds,)

        console.log({username:Username,password:Password, HashedPassword: hasshed,Class:Year+ '' + Class }) 

    Password = hasshed
    let user = await Userr.findOne({Username})

    //checking again for safety mesures
    if(user){
        return res.status(400).json({error:"Username is already in use If its you please login"})
    }



    
    const serSchema = await UserSchema.create({
        Year,Class,Username,Password
    })
    const token = creatToken(serSchema._id);
    res.cookie('token', token, { 
        httpOnly: true, 
        secure: process.env.NODE_ENV === 'production', 
        sameSite: 'Strict', 
        maxAge: 45 * 60 * 1000 
      });
        console.log(`${Username} User Created Year+Class:${Year+Class}` )

    res.status(200).json({Usershcema:serSchema,jwt:token})

 
    // res.json({username:Username,password:Password, HashedPassword: hasshed,Class:Class+ '' + Year }) 

}  catch (error) {
    console.log(error)
        res.status(500).json({error:"There was a server error "})
    }
}
    

const loginPlayer = async(req,res) =>{
    try {

        const{Username,Password,Class,Year} = await req.body 

        if (!Password || !Username ) {
            return res.status(400).json({ error: "You forgot to fill some fields in" });
        }
        const Userr = UserSchema

        let user = await Userr.findOne({Username})


        if(!user){
            return res.status(400).json({erorr:"No user could be found"})
        }
        const token = creatToken(user._id);

        let canlogin = await bcrypt.compare(Password,user.Password)
        if(canlogin){
            const session = new Session({ userId: user._id, token });
            await session.save();
            res.status(200).json({succes:"User logged in succesfully",JWT:token})
        }
        else{
            res.status(400).json({eror: canlogin+"can't login"})
        }
    } catch (error) {
        console.log(error)
        res.status(500).json({error:"there was a server error"})
    }
}
const logeout = async(req,res) =>{
    await Session.deleteOne({ token: req.cookies.token });
    res.clearCookie('token');
    res.redirect('/');
}

const debugAuth = async(req,res) =>{
    const session = await Session.findOne({ userId: decoded.userId, token });
    if (!session) {
      return res.status(401).json({ message: 'Session expired' });
    }
    res.status(200).json({i:"Server working"})
}
module.exports = {
    creatnewdatasheet,
    getallplayers,
    getplayer,
    deletepPlayerData,
    deletePlayers,
    updateplayer,
    registerPlayer,
    debugregisterPlayer,
    loginPlayer,
    logeout,
    debugAuth
}