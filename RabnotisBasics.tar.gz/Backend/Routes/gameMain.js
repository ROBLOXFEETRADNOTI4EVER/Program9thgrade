const express = require('express');
const r = express.Router()
const PlayerSchema = require('../Models/Player');
const { default: mongoose } = require('mongoose');
const Session = require('../Models/Session')

const cookieParser = require('cookie-parser')
const {creatnewdatasheet,
    getallplayers,
    getplayer,
    deletepPlayerData,
    deletePlayers,
    updateplayer,
    registerPlayer,
    debugregisterPlayer,
    loginPlayer,
    logeout,
    debugAuth

} = require('../Controllers/playerController')



  
var cors = require('cors')

r.use(cors({
    origin: '*',
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type', 'Authorization'],
}));
r.use(express.urlencoded({ extended: true }));

// GET all leaderboard on future
r.get('/',getallplayers,)
r.use(cookieParser());
r.post('/register',registerPlayer)
r.post('/debug/register',debugregisterPlayer)
r.post('/login',loginPlayer)

r.get('/logout',logeout)

// get single player leader bord things
r.get('/:id',getplayer)


// POST REQUEST

r.post('/leaderboard', creatnewdatasheet)

// Delete requst

r.delete('/:id',deletepPlayerData)

//  Delete all players WARNING
r.delete('/',deletePlayers)

// update a workout

r.patch('/:id',updateplayer,)



module.exports = r