const mongoose  = require('mongoose')
const Schema = mongoose.Schema;

const studentSchema = new Schema({
    Year:{
        type: Number,
        enum:[9,10,11,12,13,"Else"], // Enum can also work with numbers
        required: true
    },
    Class:{
        type:String,
        enum:["A","B","C","D","Else"], // enum makes it chose from an array 
        required:true
    },
    Username:{
        type:String,
        unique:true, // unquire so no bunch of the same shit 
        minlength: 3,
        maxlength: 15,
        match:[/^[a-zA-Z0-9_]+$/,"Invalid username. USe only letters, numbers and underscores"],
        validate:{
            validator: function(value){
                return!/^(admin|root|moderator|system)$/i.test(value); // prevents reserved names
            },
            message: "Username isn't allowed"
        },
        required:true
    },
    Password: {
        type: String,
        minlength: 8,
        maxlength: 72, 
        validate: {
            validator: function(value) {
                if (!value.startsWith("$2b$")) {
                    return /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,20}$/.test(value);
                }
                return true; 
            },
            message: "Invalid password: Must be 8-20 characters long, include at least one uppercase letter, one lowercase letter, one number, and one special character."
        },
        required: true
    }



},{timestamps:true})

module.exports = mongoose.model('studentSchema', studentSchema);
