const { default: mongoose } = require('mongoose');
const moongose = require('mongoose');
const Schema = moongose.Schema;

const PlayerSchema = new Schema({
    username:{
        type: String,
        required: true
    },
    playtime:{
        type: String,
        required: true
    },

    tasks_Solved: {
        type: Number,
        required: true
    }
},{timestamps: true})

module.exports =  mongoose.model('Player',PlayerSchema)