const express = require('express');
const app = express();
const mongoose = require('mongoose');
require('dotenv').config()
const path = require('path');

var cors = require('cors')


app.use(cors({
    origin: '*',
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type', 'Authorization'],
}));

const gameRouter = require('../Backend/Routes/gameMain')

app.use(express.json())
app.use('/game',gameRouter)

// midldeware
app.use((req,res,next) =>{
    console.log(req.path, req.method)
    next()
})
 
app.use(express.static(path.join(__dirname, '../Frontend/hungary/dist')));
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../Frontend/hungary/dist', 'index.html'));
});
// COONECT TO DB 

const connecttomongose = async() =>{
    try {
       await mongoose.connect(process.env.MONGODB_URI ,{
        retryWrites: true,
        retryReads: true
       })
        console.log("Connected to Database ")
    } catch (error) {
        console.error(error)
    }
}
connecttomongose()

app.listen(process.env.PORT, '0.0.0.0', () => {
    console.log('Server running on port 2850');
});