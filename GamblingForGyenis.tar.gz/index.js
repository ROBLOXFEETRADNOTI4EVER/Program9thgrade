let balance = 900;
let bet = 0; 
const Errormsg = document.getElementById("Error");
let error = "";



Errormsg.innerHTML = error;

const balanceElement = document.getElementById("balance");
balanceElement.innerHTML = balance;
let bettingAmount = document.querySelector("#number");
document.querySelector("#Submit").addEventListener("click", function () {
  bet = parseFloat(bettingAmount.value);




  if (isNaN(bet) || bet <= 0) {
    alert("Please enter a valid betting amount.");
    return;
  }

  console.log("Betting amount: $" + bet);

  if (bet > balance) {
    console.log("You can't bet that");
    error = "You can't bet that amount since it is greater than your balance";
    erordisplay();
    return;
  } else {
    balance -= bet;
    error = ""; 
    erordisplay(); 
    result(); 
  }

  balanceElement.innerHTML = balance;
  bettingAmount.value = '';
});
const betButtons = document.querySelectorAll(".Betbtn, .Betbtnyellow, .Betbtnred");
betButtons.forEach(button => {
  button.addEventListener("click", () => {
    const betValue = button.getAttribute("data-bet");
    bettingAmount.value = betValue;  
  });
});
function erordisplay() {
  Errormsg.innerHTML = error;  
  setTimeout(() => {
    Errormsg.innerHTML = ""; 
  }, 4000);
}
let resultbeta = "";
let winorlost = document.getElementById("loseWin");
winorlost.innerHTML = `${resultbeta}`;
function result() {
  let loadingMessage = "Please wait...";
  winorlost.innerHTML = loadingMessage;
  setTimeout(() => {
    let randomresult = Math.round(Math.random());
    if (randomresult === 0) {
      resultbeta = "You won";
      winorlost.innerHTML = `${resultbeta}`;
      balance += (bet * 1.5); 
    } else {
      resultbeta = "You Lost";
      winorlost.innerHTML = `${resultbeta}`;
    }
    balanceElement.innerHTML = balance.toFixed(0);
  }, Math.floor(Math.random() * (3000 - 1500 + 1)) + 1500); 
}
